This plugin removes all subtitle datastreams that contain
songs or signs in the title of the subtitle metadata.

:::warning
I offer no guarantee for this plugin. This works for my use case. Please do tests first.
:::