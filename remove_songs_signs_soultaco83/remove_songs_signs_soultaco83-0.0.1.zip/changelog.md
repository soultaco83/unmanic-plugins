**<span style="color:#56adda">0.0.1</span>**
- Initial Version
- Based on Josh's remove_image_subtitles v.0.04
