**<span style="color:#56adda">0.0.1</span>**
- Initial version
- Fork from Josh5 extract_srt_subtitles_to_files
- Changes the extraction of SRT/Subrip to Extracting ASS and SSA
- Adds a tag called Subs to the files instead of using .unmanic