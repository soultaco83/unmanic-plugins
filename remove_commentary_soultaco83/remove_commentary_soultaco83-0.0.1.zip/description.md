This plugin removes all audio streams that contain
commentary in the metadata title

:::warning
I offer no guarantee for this plugin. This works for my use case. Please do tests first.
:::